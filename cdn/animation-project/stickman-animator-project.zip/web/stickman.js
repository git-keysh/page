const config = { stiffness: 120, damping: 9, gravity: 900 };
const pose = {
  leftHand: { x: -28, y: 140 },
  rightHand: { x: 28, y: 140 },
  lean: 0
};

const createStickman = (canvas, config, pose, root = document.documentElement) => {
  const ctx = canvas.getContext('2d');
  const DT = 1 / 240;
  const TAU = Math.PI * 2;
  const L = { thigh: 80, shin: 80, torso: 110, upper: 72, fore: 72, head: 38, stance: 26 };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  const fresh = () => ({
    t: 0,
    ready: false,
    left: { x: 0, y: 0, vx: 0, vy: 0 },
    right: { x: 0, y: 0, vx: 0, vy: 0 },
    lean: { a: 0, v: 0 },
    head: { x: 0, y: 0, vx: 0, vy: 0 }
  });

  let sim = fresh();
  let joints = null;
  let raf = 0;

  const spring = (s, tx, ty, k, c, g) => {
    s.vx += ((tx - s.x) * k - c * s.vx) * DT;
    s.vy += ((ty - s.y) * k - c * s.vy + g) * DT;
    s.x += s.vx * DT;
    s.y += s.vy * DT;
  };

  const step = () => {
    if (config.script) config.script(sim.t, pose);
    if (!sim.ready) {
      Object.assign(sim.left, pose.leftHand);
      Object.assign(sim.right, pose.rightHand);
      sim.lean.a = pose.lean;
      sim.ready = true;
    }
    spring(sim.left, pose.leftHand.x, pose.leftHand.y, config.stiffness, config.damping, config.gravity);
    spring(sim.right, pose.rightHand.x, pose.rightHand.y, config.stiffness, config.damping, config.gravity);
    const push = -(sim.left.vx + sim.right.vx) * 0.006;
    sim.lean.v += ((pose.lean + push - sim.lean.a) * 90 - 8 * sim.lean.v) * DT;
    sim.lean.a += sim.lean.v * DT;
    spring(sim.head, -sim.lean.v * 0.18, 0, 140, 10, 0);
    sim.t += DT;
  };

  const ik = (a, b, l1, l2, side) => {
    let dx = b.x - a.x, dy = b.y - a.y;
    let d = Math.hypot(dx, dy) || 1e-6;
    const max = (l1 + l2) * 0.995;
    if (d > max) { dx *= max / d; dy *= max / d; d = max; }
    const base = Math.atan2(dy, dx);
    const ang = Math.acos(clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1));
    const p1 = { x: a.x + l1 * Math.cos(base + ang), y: a.y + l1 * Math.sin(base + ang) };
    const p2 = { x: a.x + l1 * Math.cos(base - ang), y: a.y + l1 * Math.sin(base - ang) };
    const s1 = 0.6 * side * (p1.x - a.x) + (p1.y - a.y);
    const s2 = 0.6 * side * (p2.x - a.x) + (p2.y - a.y);
    return [a, s1 >= s2 ? p1 : p2, { x: a.x + dx, y: a.y + dy }];
  };

  const draw = () => {
    const css = getComputedStyle(root);
    const read = (name, fallback) => css.getPropertyValue(name).trim() || fallback;
    const accent = read('--accent', '#6aa8ff');
    const line = parseFloat(read('--line', '14'));
    const glow = parseFloat(read('--glow', '0.8'));
    const bg = read('--bg', '#07090e');
    const w = canvas.width, h = canvas.height;
    const S = Math.min(w, h) / 540 * (config.zoom || 1);
    const gy = h * (config.ground || 0.88);
    const a = sim.lean.a * Math.PI / 180;
    const up = { x: Math.sin(a), y: -Math.cos(a) };
    const talk = config.talk ? config.talk(sim.t) : 0;
    const hip = { x: w / 2, y: gy - 150 * S + Math.sin(sim.t * 2.1) * 2 * S };
    const at = (k) => ({ x: hip.x + up.x * L.torso * k * S, y: hip.y + up.y * L.torso * k * S });
    const neck = at(1);
    const shoulder = at(0.88);
    const R = L.head * S;
    const headC = { x: neck.x + up.x * R + sim.head.x * S, y: neck.y + up.y * R + sim.head.y * S - talk * 2 * S };
    const legL = ik(hip, { x: hip.x - L.stance * S, y: gy }, L.thigh * S, L.shin * S, -1);
    const legR = ik(hip, { x: hip.x + L.stance * S, y: gy }, L.thigh * S, L.shin * S, 1);
    const armL = ik(shoulder, { x: shoulder.x + sim.left.x * S, y: shoulder.y + sim.left.y * S }, L.upper * S, L.fore * S, -1);
    const armR = ik(shoulder, { x: shoulder.x + sim.right.x * S, y: shoulder.y + sim.right.y * S }, L.upper * S, L.fore * S, 1);

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);
    const bgGlow = ctx.createRadialGradient(w / 2, h * 0.5, 10, w / 2, h * 0.5, Math.max(w, h) * 0.75);
    bgGlow.addColorStop(0, accent);
    bgGlow.addColorStop(1, 'transparent');
    ctx.globalAlpha = 0.16;
    ctx.fillStyle = bgGlow;
    ctx.fillRect(0, 0, w, h);
    ctx.globalAlpha = 1;
    const floor = ctx.createRadialGradient(w / 2, gy, 4, w / 2, gy, 190 * S);
    floor.addColorStop(0, accent);
    floor.addColorStop(1, 'transparent');
    ctx.save();
    ctx.translate(0, gy);
    ctx.scale(1, 0.12);
    ctx.translate(0, -gy);
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = floor;
    ctx.fillRect(0, gy - 200 * S, w, 400 * S);
    ctx.restore();

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#f3f6fb';
    ctx.lineWidth = line * S;
    ctx.shadowColor = accent;
    ctx.shadowBlur = 26 * glow * S;
    const path = (pts) => {
      ctx.beginPath();
      pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
      ctx.stroke();
    };
    path(legL);
    path(legR);
    path([legL[2], { x: legL[2].x - 18 * S, y: legL[2].y }]);
    path([legR[2], { x: legR[2].x + 18 * S, y: legR[2].y }]);
    path([hip, neck]);
    path(armL);
    path(armR);

    ctx.save();
    ctx.translate(headC.x, headC.y);
    ctx.rotate(a);
    ctx.beginPath();
    ctx.arc(0, 0, R - line * S / 2, 0, TAU);
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.lineWidth = line * S * 0.34;
    const blink = Math.abs((sim.t % 3.4) - 1.7) > 1.62 ? 0.15 : 1;
    [-1, 1].forEach((s) => {
      ctx.beginPath();
      ctx.arc(s * R * 0.38, -R * 0.1, R * 0.27, 0, TAU);
      ctx.fillStyle = accent + '33';
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(s * R * 0.38 + sim.head.x * 0.2, -R * 0.1, R * 0.07, R * 0.07 * blink, 0, 0, TAU);
      ctx.fillStyle = '#fff';
      ctx.fill();
    });
    ctx.beginPath();
    ctx.moveTo(-R * 0.11, -R * 0.1);
    ctx.lineTo(R * 0.11, -R * 0.1);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-R * 0.22, R * 0.42);
    ctx.quadraticCurveTo(0, R * (0.5 + 0.1 * (1 - talk) + 0.5 * talk), R * 0.22, R * 0.42);
    ctx.stroke();
    ctx.restore();

    ctx.shadowBlur = 0;
    joints = { S, shoulder, hip, head: headC, R };
    if (config.overlay) config.overlay(ctx, sim.t, canvas);
  };

  const advance = (target) => {
    if (target < sim.t - 1e-9) sim = fresh();
    while (sim.t < target - 1e-9) step();
  };

  const seek = (t) => {
    advance(t);
    draw();
  };

  const play = () => {
    let last = performance.now();
    const frame = (now) => {
      advance(sim.t + Math.min(0.05, (now - last) / 1000));
      last = now;
      draw();
      raf = requestAnimationFrame(frame);
    };
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);
  };

  return { seek, play, stop: () => cancelAnimationFrame(raf), joints: () => joints };
};

const stickman = createStickman(document.getElementById('stage'), config, pose);
stickman.play();