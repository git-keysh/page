# Stickman Animator

Animate a physics-driven stickman with HTML, CSS and JavaScript, then render it to a 1080x1920, 60 fps MP4 with Python.

Made by Keyshaun Sookdar (Former Robotics President at Waterloo Secondary School)

## Requirements

- Python 3.10 or newer
- ffmpeg and ffprobe on your PATH
- Chromium for Playwright

## Setup

```
pip install -r requirements.txt
python -m playwright install chromium
```

## Render a video

```
python Generate.py --name demo
```

The finished file appears in `output/demo.mp4`. The first run downloads a small offline voice model.

## Useful options

```
python Generate.py --still 2.0      save one frame to build/still.png
python Generate.py --preview        open canva/draft.html in your browser
python Generate.py --no-music       skip background music
python Generate.py --voice af_heart choose another voice
```

## Project layout

| Path | Purpose |
| --- | --- |
| `Generate.py` | starts the whole job |
| `canva/draft.html` | the animation, drawn on a canvas |
| `canva/caption.json` | what the character says and when |
| `bin/audiogen.py` | text to speech and timing |
| `bin/render.py` | captures frames in headless Chromium |
| `bin/stabilizer.py` | ffmpeg encode, music, watermark, verification |
| `web/` | standalone HTML, CSS and JS version of the character |
| `assets/` | optional `backgroundaudio.mp3` and `watermark.png` |

## How it works

`canva/draft.html` exposes `window.renderFrame(t)`. The renderer calls it for every frame at 60 fps and saves a screenshot, so the video is exact regardless of computer speed. Edit the `script` function to change the movement and `caption.json` to change the dialogue.
