import argparse
import json
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BIN = ROOT / "bin"
sys.path.insert(0, str(BIN))

CAPTIONS = ROOT / "canva" / "caption.json"
MUSIC = ROOT / "assets" / "backgroundaudio.mp3"
HTML = ROOT / "canva" / "draft.html"
WATERMARK = ROOT / "assets" / "watermark.png"
OUTPUT = ROOT / "output"
BUILD = ROOT / "build"


def log(*a):
    print("[generate]", *a, flush=True)


def setup():
    log("installing Python packages ...")
    subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")], check=True)
    log("installing Chromium for the renderer ...")
    subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True)
    log("done.  ffmpeg must also be installed and on PATH: https://ffmpeg.org/download.html")


def preflight(captions):
    problems = []
    for exe in ("ffmpeg", "ffprobe"):
        if shutil.which(exe) is None:
            problems.append(f"{exe} not found on PATH  ->  https://ffmpeg.org/download.html")
    for mod in ("numpy", "playwright", "PIL"):
        try:
            __import__(mod)
        except ImportError:
            problems.append(f"python package '{mod}' missing")
    for f in (captions, HTML):
        if not f.exists():
            problems.append(f"missing file: {f.relative_to(ROOT)}")
    if problems:
        print("\nCannot start:\n  - " + "\n  - ".join(problems))
        print("\nFix the packages with:  python Generate.py --setup\n")
        sys.exit(1)
    try:
        json.loads(captions.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"{captions} is not valid JSON: {e}")
        sys.exit(1)


def main():
    ap = argparse.ArgumentParser(description="Animation video generator")
    ap.add_argument("--name", default="demo", help="output file name (without .mp4)")
    ap.add_argument("--captions", default=str(CAPTIONS), help="script to use (default canva/caption.json)")
    ap.add_argument("--music", default=None, help="background music file (default assets/backgroundaudio.mp3 if it exists)")
    ap.add_argument("--music-volume", type=float, default=0.5, help="music volume, 0.5 = 50%%")
    ap.add_argument("--no-music", action="store_true")
    ap.add_argument("--engine", default="auto", choices=["auto", "kokoro", "edge", "pyttsx3"])
    ap.add_argument("--voice", default=None)
    ap.add_argument("--workers", type=int, default=None, help="parallel browsers (default: CPU count)")
    ap.add_argument("--still", type=float, default=None, help="render only the frame at this second")
    ap.add_argument("--preview", action="store_true", help="open canva/draft.html in the browser")
    ap.add_argument("--keep-frames", action="store_true")
    ap.add_argument("--setup", action="store_true")
    a = ap.parse_args()

    if a.setup:
        return setup()
    captions = Path(a.captions)
    if not captions.is_absolute():
        captions = (Path.cwd() / captions) if (Path.cwd() / captions).exists() else ROOT / captions
    preflight(captions)

    import audiogen, render, stabilizer
    t0 = time.time()
    OUTPUT.mkdir(exist_ok=True)
    BUILD.mkdir(exist_ok=True)

    log("1/3  voice")
    resolved = audiogen.generate(captions, BUILD, engine=a.engine, voice=a.voice)

    if a.preview or a.still is not None:
        render.build_data(resolved)
        if a.still is not None:
            render.render_still(a.still, BUILD / "still.png")
        else:
            webbrowser.open(HTML.as_uri())
        return

    log("2/3  render")
    raw = render.render(resolved, fps=60, workers=a.workers, keep_frames=a.keep_frames)

    log("3/3  stabilize + watermark")
    out = OUTPUT / f"{a.name}.mp4"
    music = None if a.no_music else (Path(a.music) if a.music else (MUSIC if MUSIC.exists() else None))
    if music is None and not a.no_music:
        log("no assets/backgroundaudio.mp3 found - rendering without background music")
    stabilizer.stabilize(raw, BUILD / "voice.wav", WATERMARK, out, music, a.music_volume)

    log(f"DONE in {time.time() - t0:.0f}s  ->  {out}")


if __name__ == "__main__":
    mp = __import__("multiprocessing")
    mp.freeze_support()
    main()
